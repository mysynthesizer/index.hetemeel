chrome.browserAction.onClicked.addListener(function(e) {
    e.url && e.url.includes("whatsapp") && 
    //chrome.tabs.executeScript(null, {file: "js/siema.min.js"}) &&
    chrome.tabs.executeScript(null, { file: "smph/6f776e656420736e757266.js"})
});

// var wProCache={"wProID": chrome.runtime.id}                           
// chrome.storage.local.set({"wProCache":wProCache}, function() {});

//chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
/*chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    
    alert("ooiop");

    sendResponse();
    
    if (request.action === "createScript") {
        
        //return chrome.runtime.getURL(request.data);
        var doc=request.data.window.document;
        var script=request.data.script;
        
        var s = doc.createElement( 'script' );
        s.setAttribute( 'src', chrome.runtime.getURL(script) );
        document.body.appendChild( s );
        return document;
    }
    
  });*/