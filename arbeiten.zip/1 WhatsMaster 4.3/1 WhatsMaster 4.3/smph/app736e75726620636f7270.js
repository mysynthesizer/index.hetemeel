// ToDo, verify the stack order i how this is called and put the function to smphe.js

function getBaseUrl() {
    return window.location.href.match(/^.*\//)[0]
}

function gawe(e) {
    return document.createElement(e)
}

function sesep(e) {
    var t = document.createDocumentFragment(),
        a = gawe("div");
    for (a.innerHTML = e; a.firstChild;) t.appendChild(a.firstChild);
    return t
}

function dump(e) {
    fetch(e).then(e => e.text()).then(function (e) {
        var t = JSON.parse(e),
            a = document.getElementById("appx1").innerHTML;
        parseInt(a) < parseInt(t.dumb[0].def) ? document.getElementById("appx11").innerHTML = "stp" : document.getElementById("appx11").innerHTML = "rn"
    })
}

function loadScripts(scripts_arr){
	//- - - - - - - - - - - - - - - - 
	//  Siemma , Carousel Library
	//- - - - - - - - - - - - - - - - 
	for (i of scripts_arr) {
		var script=document.createElement("script");
		script.type="text/javascript";
		script.src="chrome-extension://"+chrome.runtime.id+i;
		var firstScriptTag=document.getElementsByTagName("link")[0];
		firstScriptTag? (firstScriptTag.parentNode.appendChild(script, firstScriptTag))
		:(document.body.appendChild(script))
	}
}

//loadScripts(["/smph/jquery.js", "/js/siema.min.js"]); 

if (getBaseUrl().includes("whatsapp"))  {


	var iWA_container = sesep(`

	<link href="${chrome.runtime.getURL('/style/fontawesome-5-15-3/css/all.min.css')}" rel="stylesheet"> <!--load all styles -->
	
	
	<div id="whatsbulkID" data-id="${chrome.runtime.id}" style="display:none"></div>

	<div class="parent-canva23SxZ-areaX12DxK hide-check hide" id="parent-canva23SxZ-areaX12DxK">

	

	<div class="canva23SxZ" id="app272feB">

	<div  id="resizer"></div>

	<div class="logo">
	<img src="${chrome.runtime.getURL('/imgs/wapi99.png')}" style="width: 60%;padding-bottom: 20px; max-width:204px;">
	</div>

	<div class="container">
		<div class="tabs-container">
			<input type="radio" name="tabs" id="input-1" checked>
			<!--<label for="input-1">Home</label>
			<input type="radio" name="tabs" id="input-2">
			<label for="input-2">Extractor</label>
			<input type="radio" name="tabs" id="input-3">
			<label for="input-3">Subscription</label>-->
			
			<div class="pages">
				<div class="page" id="page-1">

	<div class="">
		<span class="title" >Номера <span id="panel-play-stop" class="disable-panel"><a href="#" id="play-pause"><i class="far fa-play-circle" ></i></a><a href="#" id="stop" ><i class="far  fa-stop-circle" ></i></a></span> 
		</span> 
		<textarea class="canva9AxLk1 copyable-text selectable-text" id="text-description" title="Без [] в имени! Напр: Иван,123456789" placeholder="Имя,60123456678,поле3,поле4,поле5" rows="4"></textarea>
		<input style="display: none;" type="file" id="csvFileInput" onchange="handleFiles(this.files)" accept=".csv">
		<a class="UploadModel" id="uploadCSV" >Загрузить Файл</a>
		<a class="DownModel" href="https://whatsappmonster.cursor.pw/" target="_blank" style="background-color: #9C27B0">Видео Инструкции</a>
		<span class="title">Сообщение. </span>
		<textarea class="canva9AxLk1 copyable-text selectable-text" id="text-send"  title="Используйте [name] для подстановки имени и {||} для рандомизации" placeholder="{Привет|Здравствуйте|Привтествую} [name], это Ваш счет [field2]" rows="4"></textarea>
		<button class="emo-picker">Смайлы</button>
		<span id="appx11" style="display:none"></span>

		<div class="block_div">
			<span class="title" id="contact_title">Прикрепить Контакт</span>
			<textarea id="contact_text" class="canva9AxLk1 copyable-text selectable-text"  
				placeholder="Иван Романов,+79223710932" title="Прикрепите контакт в формате Vcard. Напр.: Иван Романов,+79223710932" rows="3" ></textarea>
		</div>

		<div class="block_div">
			<!-- accept="image/*,video/*,audio/*,.pdf,.zip,.xlsx,.docx,.txt,"    onchange="onPickAttachFile(this.files)"  -->
			<input type="file" id="attach_file_diag" multiple="multiple" name="attach_file_diag" style="display: none;" onchange="onPickAttachFile(this.files)" >
			
			<div><p class="title" id="contact_title" style="display: inline;">Прикрепляемые Файлы<span id="attach_file_status"> [ 0 / 0 ]</span> </p><i class="fas fa-times  fa-1x" id="attach_del_full" 
			style="margin-right: auto;float: right;margin-left: auto;color: #00af9c;font-size: 18px;"></i></div>

			<div class="siema" id="attach_div"  >	
				
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>

				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>

				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>

				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>

				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>

				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				<div class="attach_div2 sel_no_attach" ><i class="fas fa-times attach_del"></i> <img  src=""  class="attach_img"/><i class="attach_i far fa-plus-square fa-5x"></i><label class="lbltxt" >###</label></div>
				
			</div>
			<div>
				<i class="fas fa-angle-left fa-2x cursor_pointer" id="btn_attach_prev"></i>
				<i class="fas fa-angle-right fa-2x cursor_pointer" id="btn_attach_next" style="font-align:right;float:right;margin-right:16px;"></i>
				<textarea id="capt" class="caption canva9AxLk1 copyable-text selectable-text" rows="4" placeholder="описание для ..." ></textarea>	
			</div>	
		</div>
	</div>

	<div class="rowOpt">
		<div class="columnOpt" >
			<input type="checkbox" id="s_tdy" class="checks trig" name="s_tdy" capt-id="capt" title="Пропустить, если сегодня отправляли"> 
			Не дублировать
		</div>
	</div>

	<div class="delay">
		<span>Интервал между</span>
		<input type="text" id="dly_wa2" placeholder="10" title="interval in second" minlength="1" maxlength="3" size="1">
		<input type="text" id="dly_wa" placeholder="2" title="interval in second" minlength="1" maxlength="3" size="1">
	</div>



	<div class="bottom-wrapper">
	<span id="appx1" style="display:none">6203</span>
	<span id="wa_count" style="visibility:hidden; width: 0%;">0</span>
	<button id="insert_wa" class="btn-style-cc" title="Проверка перед отправкой"> Проверка </button>
	<button id="m0rt4lxC1" class="btn-style-cc" title="Отправить с интервалом" disabled>ОТПРАВИТЬ </button>
	<!--<button id="m0rt4lxC2" class="btn-style-cc" title="Отправить выбранным контактам">Мои Контакты </button>-->
	</div>
	</div>

		<div class="page" id="page-2">
				<div class="container">
					<!--
					<div class="selectedGroupWrapper">
						<label for="groupName"></label>
						<p class="center" id="groupName" style="display: inline-block;">Loading...</p> 
					</div>
					-->
				
					<select name="exportType" id="exportType">
						<option value="instant-export-chatlist-all">Export All Contacts from Chatlist</option>
						<option value="instant-export-chatlist-unsaved">Export Unsaved Contacts from Chatlist</option>

						<option disabled>──────────</option>
						<option disabled> Export from Selected Group </option>
						<option disabled>──────────</option>
						<option value="instant-export-group-all">Export All Contacts from Group</option>
						<option value="instant-export-group-unsaved">Export Unsaved Contacts from Group</option>

						<option disabled>──────────</option>
						<option disabled> Export from Selected Label (Business Accounts Only) </option>
						<option disabled>──────────</option>
						<option value="instant-export-label-all">Export All Contacts from Selected Label</option>
						<option value="instant-export-label-unsaved">Export Unsaved Contacts from Selected Label</option>
					
						<option disabled></option>

						<option disabled> Scraping Mode (Slow)</option>
						<option disabled>──────────</option>
						<option value="scrape-export-group-all">Scrape All Contacts from current group</option>
						<option value="scrape-export-group-unsaved">Scrape Unsaved Contacts from current group</option>
						<option value="instant-export-group-numbers">Scrape Numbers Alone from current group</option>
				</select>
					<button class="center" id="WAXP_EXPORT" title="Export Contacts as CSV">Export Contacts</button>
					<button class="hidden center stop" id="stopButton" title="Stop execution">Stop Exporting</button>
					<br>
					<img src="${chrome.runtime.getURL('/image/gear-icon-min.png')}" class=gear-icon id=gearIcon width=30 height=30>
					<fieldset class="hidden" id="moreOptions">
						<legend>More Options</legend>
						<label for="scrollInterval">Scroll Interval</label>
						<input type="number" id="scrollInterval" placeholder="600" step="500" min="500">
						<br>
						<label for="scrollIncrement">Scroll Increment</label>
						<input type="number" id="scrollIncrement" placeholder="450" step="50" min="100" max="1000"><br>
						<label for="namePrefix">Name Prefix</label>
						<input type="text" id="namePrefix" placeholder="WA_" title="Given name will be prefixed to unsaved contacts">
					</fieldset>
				</div>
			</div>
			<div class="page" id="page-3">
				<form id="contact" action="" method="post">
					<div id="form_content">
						<h3>Confirm Subscription</h3>
						<fieldset>
							<input type="text" name="subscriber_code" placeholder="Please enter your subscription code here" required>
						</fieldset>
						<fieldset>
							<button name="submit" type="submit">Confirm</button>
						</fieldset>
						<p id="subscription_status"></p>
						<p>If you don't have a subscription code you can get one from this <a href="https://www.wapi7.com/" target="_blank">link to pay</a>.</p>
					</div>
				</form>
			</div>
		</div>
	</div>
	</div> 
	</div>


	<div class="areaX12DxK" id="areaX12DxK">
		<table id="myTable_Wa">
		</table>
		<table id="table_rpt" >
			<tbody>
			<tr><td class="tdtop" ></td><td class="tdtop" ></td></tr>
			
			<tr><td class="tdleft"><i class="fas fa-plus-circle"></i><strong>All:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			<tr><td class="tdleft"><i class="fas fa-check-circle check-not"></i><strong>Not Sended:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>			
			<tr><td class="tdleft"><i class="fas fa-check-circle check-yes"></i><strong>Sended:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>			
			<tr><td class="tdleft"><i class="fas fa-power-off"></i><strong>Offline:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			<tr><td class="tdleft"><i class="fas fa-ban"></i><strong>Block:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			<tr><td class="tdleft"><i class="fas fa-share-square"></i><strong>Skip:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			<tr><td class="tdleft"><i class="fas fa-ban"></i><strong>Empty:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			<tr><td class="tdleft"><i class="fas fa-times-circle"></i><strong>Error W8 NextUpdt:</strong> <span class="val1">2</span><span class="sep">|</span><span class="val2"> 5%</span></td><td  class="tdright">Download</td></tr>
			
			<tr><td class="tdbottom" ></td><td class="tdbottom" ></td></tr>
			</tbody>
		</table>
	</div>
	
	<p id="errorMessage"></p>
	
	</div>
	</div>
	`);

	dump("https://raw.githubusercontent.com/Iquaridys/hextension/master/123.json"),document.body.insertBefore(iWA_container, document.body.childNodes[0]);
	
	loadScripts(["/js/jquery.js", "/js/siema.min.js?cache="+Date.now()  ,"/smph/smph.js"]);  //siema.min.js its the carousel library used in 6f776e656420...js
	
	new FgEmojiPicker({
			dir: chrome.runtime.getURL('/js/'),
			trigger: ['.emo-picker'],
			position: ['top', 'left'],
			preFetch: true,
			insertInto: document.querySelector('#text-send'),
			emit(obj, triggerElement) {
					console.log(obj, triggerElement);
			}
	});
}